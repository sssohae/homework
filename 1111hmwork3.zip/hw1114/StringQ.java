package com.yedam.hw1114;

import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class StringQ {
	public static void main(String[] args) {

		// Q1.
		Scanner sc = new Scanner(System.in);

//		String input = sc.nextLine();
//
//		char cha;
//
//		for (int i = input.length() - 1; i > -1; i--) { // Q. 이거 중간 조건식 ==0 하면 안되는데 왜??
//			cha = input.charAt(i);
//			System.out.print(cha);
//		}

//		 Q2.

		int engCnt = 0;
		int korCnt = 0;
		int numCnt = 0;

		byte[] bytes2 = null;
		String input2 = sc.nextLine();

		for (int i = 0; i < input2.length(); i++) {
			bytes2 = input2.getBytes();
			if (bytes2[i] == 1) {
				engCnt++;
				numCnt++;
			}else if(bytes2[i] == 3) {
				korCnt++;
			}
		}
		System.out.println("숫자 : " + numCnt + "영어 : " + engCnt + "한국어 : " +korCnt);

		// 영어 1바이트 숫자 1바이트 한글 3바이트

//	byte[] bytes2 = null;
//	String str = "안녕하세요";
//	bytes2 = str.getBytes();
//
//	System.out.println(bytes2.length); // 한글은 1개에 3바이트라 15length나온다
//
//	String str3 = new String(bytes2);
//	System.out.println("bytes2 -> String " + str3);
//
//	try {
//		byte[]bytes3 = str.getBytes("EUC-KR");
//		System.out.println("bytes3.length : " + bytes3.length );
//		
//		String str4 = new String(bytes3, "EUC-KR");
//		System.out.println("bytes3 -> string " + str4);
//	}catch(UnsupportedEncodingException e) {//문제가 생기면 이쪽으로 이동해라 예외처리 
//		e.printStackTrace();
//	}
//	
//	

		// 1. 인풋 받고 2. 알파벳 비교 if 3. 결과

		// Q3.

//	String input3 = sc.nextLine();

		// 입력받고
		// 하나씩 순서대로 자르고
		// 뒤에서 부터
		// 붙여

		// 대조해서
		// if + 카운트해서
		// 결과 출력
	}
}
