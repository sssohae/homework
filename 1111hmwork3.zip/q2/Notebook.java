package com.yedam.q2;

public interface Notebook {
	
	public static final int NOTEBOOK_MODE = 1;
	
	public abstract void writeDocumentation();
	public abstract void searchInternet();
	

}
