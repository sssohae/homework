package com.yedam.q2;

public class PortableNotebook implements Notebook, Tablet {

	private int mode;
	private String docu;
	private String internet;
	private String video;
	private String app;

	public PortableNotebook(String docu, String internet, String video, String app) {
		mode = 1;
		this.docu = docu;
		this.internet = internet;
		this.video = video;
		this.app = app;
		System.out.println("NOTEBOOK_MODE");
	}

	@Override
	public void watchVideo() {
		System.out.println(video + "를 시청.");

	}

	@Override
	public void writeDocumentation() {
		System.out.println(docu + "을 통해 문서를 작성.");

	}

	@Override
	public void searchInternet() {
		System.out.println(internet + "를 통해 인터넷을 검색.");

	}

	@Override
	public void userApp() {
		if (mode == 1) {
			mode = 2;
			System.out.println(app+"을 실행");

		} else if (mode == 2) {
			System.out.println(app+"을 실행");
		}
	}
	
		
		public void changeMode() {
			if (mode == 1) {
				mode = 2;
				System.out.println("TABLET_MODE");

			} else if (mode == 2) {
				mode = 1;
				System.out.println("NOTEBOOK_MODE");
			}
		
		
		}
		
	}
