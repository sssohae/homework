package com.yedam.q2;

public interface Tablet extends Notebook{

	public static final int TABLET_MODE =2;
	public abstract void watchVideo();
	public abstract void userApp();
	
}
