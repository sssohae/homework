package com.yedam.q2;

public class Application {
public static void main(String[] args) {
	
	Tablet tb = new PortableNotebook("한글2020","영화","안드로이드앱","크롬");
	
	tb.writeDocumentation();
	tb.watchVideo();
	
	
	
	tb.userApp();
	tb.searchInternet();
	
}
}
