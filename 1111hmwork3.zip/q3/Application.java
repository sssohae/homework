package com.yedam.q3;

public class Application {
public static void main(String[] args) {

	
	

//	<< 1.LeftUP | 2.LeftDown | 3.RightUp | 4.RightDown | 5.ModeChange | 0.GameChange | 9.EXIT >>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	Keypad kp = new RPGgame();
	
	kp.leftUpButton();
	kp.rightUpButton();
	kp.changeMode();
	kp.rightUpButton();
	kp.rightDownButton();
	kp.leftDownButton();
	kp.changeMode();
	kp.rightDownButton();

	System.out.println("====================");
	
	
	Keypad kp2 = new ArcadeGame();
	
	kp2.leftUpButton();
	kp2.rightUpButton();
	kp2.leftDownButton();
	kp2.changeMode();
	kp2.rightUpButton();
	kp2.leftUpButton();
	kp2.rightDownButton();
	
	//50확률로 두 개의 게임 중 하나 셋팅 
	
}

}
