package com.yedam.q1;

public class Application {
public static void main(String[] args) {
	Keypad kp = new RPGgame();
	
	kp.leftUpButton();
	kp.rightUpButton();
	kp.changeMode();
	kp.rightUpButton();
	kp.rightDownButton();
	kp.leftDownButton();
	kp.changeMode();
	kp.rightDownButton();

	System.out.println("====================");
	
	
	Keypad kp2 = new ArcadeGame();
	
	kp2.leftUpButton();
	kp2.rightUpButton();
	kp2.leftDownButton();
	kp2.changeMode();
	kp2.rightUpButton();
	kp2.leftUpButton();
	kp2.rightDownButton();
	
	
	
}

}
